Squirmy:

squirmy was a game created for two people to play on one screen chasing
for all the red apples while trying to avoid the yellow ones. There are 
two players, a green and blue player. Player 1 is green, and Player 2 is
blue. controls are as follows:

	Player 1:
		right arrow: right
		left arrow: left
		up arrow: up 
		down arrow: down

	Player 2:
		d key: right
		a key: left
		w key: up 
		s key: down

both worms can be controlled simultaneously from the keypad arrows
ENJOY!!